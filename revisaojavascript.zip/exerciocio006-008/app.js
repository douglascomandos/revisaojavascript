// Exercicio 6:
// Escreva um programa que exiba a mensagem "Estou aprendendo JavaScript!" 5 vezes

// console.log("Estou aprendendo JavaScript!")
// console.log("Estou aprendendo JavaScript!")
// console.log("Estou aprendendo JavaScript!")
// console.log("Estou aprendendo JavaScript!")
// console.log("Estou aprendendo JavaScript!")
// console.log('-----------------')
// console.log("Estou aprendendo JavaScript! Estou aprendendo JavaScript! Estou aprendendo JavaScript! Estou aprendendo JavaScript! Estou aprendendo JavaScript!")
// console.log('-----------------')
// console.log("Estou aprendendo JavaScript! \nEstou aprendendo JavaScript! \nEstou aprendendo JavaScript! \nEstou aprendendo JavaScript! \nEstou aprendendo JavaScript!")

// alert("Estou aprendendo JavaScript! \nEstou aprendendo JavaScript! \nEstou aprendendo JavaScript! \nEstou aprendendo JavaScript! \nEstou aprendendo JavaScript!")

// document.getElementById('ex06').innerHTML = "Estou aprendendo JavaScript! <br>Estou aprendendo JavaScript! <br>Estou aprendendo JavaScript! <br>Estou aprendendo JavaScript! <br>Estou aprendendo JavaScript!"

// Exercício 7:
// Crie um programa que exiba a sequência de números de 1 a 10.
// console.log('1, 2, 3, 4, 5, 6, 7, 8, 9, 10')
// alert('1, 2, 3, 4, 5, 6, 7, 8, 9, 10')
// document.getElementById('ex07').innerHTML = '1, 2, 3, 4, 5, 6, 7, 8, 9, 10'

// ex08

console.log("Feliz Ano Novo! \nFeliz Ano Novo! \nFeliz Ano Novo!");
alert("Feliz Ano Novo! \nFeliz Ano Novo! \nFeliz Ano Novo!");
document.getElementById('ex08').innerHTML = "Feliz Ano Novo! <br> Feliz Ano Novo! <br>Feliz Ano Novo!"
 
