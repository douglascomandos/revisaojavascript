console.log('Olá mundo!!!')
console.log("Olá mundo!!!")
console.log(' Olá mundo!!!')
alert('Olá Mundo!')

document.getElementById('comandoDeSaida').innerHTML = 'Algoritmoss'
