//ex 09:
// console.log(3*3*3);
// alert(2*2*2);
// document.getElementById('ex09').innerHTML = 5*5*5
 
//ex 10:
console.log('Meu nome é Lucas Silvano Medeiros Rodrigues e tenho 22 anos de idade.');
alert('Meu nome é Lucas Silvano Medeiros Rodrigues e tenho 22 anos de idade.');
document.getElementById('ex10').innerHTML = 'Meu nome é Lucas Silvano Medeiros Rodrigues e tenho 22 anos de idade'
 