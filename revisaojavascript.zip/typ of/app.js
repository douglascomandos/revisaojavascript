let valor1 = parseFloat(prompt('Digite algo...'))
let valor2 = parseFloat(prompt('Digite algo...'))

console.log(valor1, valor2)
console.log(typeof valor1, typeof valor2)
console.log(valor1 + valor2)

// valor inteiro
// let valor3 = parseInt(prompt('Digite algo...'))
// let valor4 = parseInt(prompt('Digite algo...'))

// console.log(valor1, valor2)
// console.log(typeof valor1, typeof valor2)
// console.log(valor1 + valor2)