// Exercicio 1:
// Escreva um programa que exiba a mensagem "Olá, mundo!"

// console.log('Olá, mundo!')
// alert('Olá, mundo!')
// document.getElementById('ex01').innerHTML = 'Olá, mundo!'

// Exercicio 2:
// Escreva um programa que exiba o seu nome
// console.log('Douglas')
// alert('Douglas')
// document.getElementById('ex02').innerHTML = 'Douglas'

// Exercício 3:
// Crie um programa que exiba a soma de dois números
// console.log(8+3)
// alert(8+4)
// document.getElementById('ex03').innerHTML = 10+5

// Exercício 4:
// Crie um programa que exiba o dobro de um número.
// console.log(4*2)
// alert(4*2)
// document.getElementById('ex04').innerHTML = 5*2

// Exercício 5:
// Escreva um programa que exiba a idade de um dos seus colegas.

console.log("Meu colega tem: " + 15 + " anos de idade.")
alert("Meu colega tem: " + 15 + " anos de idade.")
document.getElementById('ex05').innerHTML = "Meu colega tem: " + 15 + " anos de idade."