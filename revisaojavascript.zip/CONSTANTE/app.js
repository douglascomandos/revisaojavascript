let numero1 = 10
console.log(numero1)
console.log(numero1 * 50)

numero1 = 5
console.log(numero1)

numero1= 101
console.log(numero1)

let numero2 = 20
console.log(numero1 * numero2)